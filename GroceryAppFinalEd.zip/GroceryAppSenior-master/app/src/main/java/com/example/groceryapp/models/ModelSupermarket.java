package com.example.groceryapp.models;

import java.io.Serializable;
import java.util.List;

public class ModelSupermarket implements Serializable {

    private String supermarketId, address, supermarketImage, supermarketName;
    Double latitude, longitude;
    List <ModelsmProduct> products;

    public List<ModelsmProduct> getProducts() {
        return products;
    }

    public void setSmProducts(List<ModelsmProduct> smProducts) {
        this.products = smProducts;
    }


    public ModelSupermarket() {
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getSupermarketId() {
        return supermarketId;
    }

    public void setSupermarketId(String supermarketId) {
        this.supermarketId = supermarketId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSupermarketImage() {
        return supermarketImage;
    }

    public void setSupermarketImage(String supermarketImage) {
        this.supermarketImage = supermarketImage;
    }

    public String getSupermarketName() {
        return supermarketName;
    }

    public void setSupermarketName(String supermarketName) {
        this.supermarketName = supermarketName;
    }
}
