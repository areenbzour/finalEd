package com.example.groceryapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Icon;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.groceryapp.R;
import com.example.groceryapp.models.ModelSupermarket;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class SupermarketActivity extends AppCompatActivity {

    Button showRouteBtn, closeButton;
    private ImageButton rateIv,shreviewIv;
    private String ShopName,shopId;
    private RatingBar ratingBar4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supermarket);

        ModelSupermarket sm = (ModelSupermarket) getIntent().getSerializableExtra("supermarket");

        showRouteBtn = findViewById(R.id.showRouteBtn);

        TextView title = findViewById(R.id.supermarketNameTv);
        TextView address = findViewById(R.id.supermarketAddressTv);
        ImageView supermarketIcon = findViewById(R.id.supermarketIconIv);
        String icon = sm.getSupermarketImage();
        rateIv=findViewById(R.id.rateIv);
        shreviewIv=findViewById(R.id.shreviewIv);
        closeButton = findViewById(R.id.closeButton);

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SupermarketActivity.this, MainUserActivity.class);
                startActivity(intent);
            }
        });

        Intent intent=getIntent();
        ShopName=intent.getStringExtra("ShopName");
        shopId=intent.getStringExtra("shopId");



        Picasso.get().load(sm.getSupermarketImage()).into(supermarketIcon);


        title.setText(sm.getSupermarketName());
        address.setText(sm.getAddress());

        Picasso.get().load(sm.getSupermarketImage()).into(supermarketIcon);

        supermarketIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent i = new Intent(this)

            }
        });

        Location ulocation = new Location("Ulocation");
        final DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Location");

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Double ulatitude = snapshot.child("latitude").getValue(Double.class);
                Double ulongitude = snapshot.child("longitude").getValue(Double.class);

                ulocation.setLatitude(ulatitude);
                ulocation.setLongitude(ulongitude);

                showRouteBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String address = "https://www.google.com/maps/dir/" + String.valueOf(ulatitude) + ',' + String.valueOf(ulongitude)
                                +"/" + String.valueOf(sm.getLatitude())+ ',' + String.valueOf(sm.getLongitude());
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(address));
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


}