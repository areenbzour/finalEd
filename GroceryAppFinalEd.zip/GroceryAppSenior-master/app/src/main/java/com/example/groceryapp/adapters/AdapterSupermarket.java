package com.example.groceryapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.groceryapp.R;
import com.example.groceryapp.activities.ShopReviewActivity;
import com.example.groceryapp.activities.writwReviewActivity;
import com.example.groceryapp.models.*;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterSupermarket extends RecyclerView.Adapter<AdapterSupermarket.HolderSupermarket>{

    private Context context;
    public ArrayList<ModelSupermarket> supermarketList;
    private AdapterSmRes.SmResListener listener;


    public AdapterSupermarket(Context context, ArrayList<ModelSupermarket> supermarketList) {
        this.context = context;
        this.supermarketList = supermarketList;
    }

    @NonNull
    @Override
    public HolderSupermarket onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate layout
        View view = LayoutInflater.from(context).inflate(R.layout.show_supermarket,parent,false);
        return new HolderSupermarket(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderSupermarket holder, int position) {

        //get data
        ModelSupermarket modelSupermarket = supermarketList.get(position);
        String id = modelSupermarket.getSupermarketId();
        String supermarketAddress = modelSupermarket.getAddress();
        String icon = modelSupermarket.getSupermarketImage();
        String name = modelSupermarket.getSupermarketName();


        holder.rateIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(view.getContext(), writwReviewActivity.class);
                intent1.putExtra("supermarket",modelSupermarket);
                view.getContext().startActivity(intent1);
            }
        });

        holder.shreviewIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(), ShopReviewActivity.class);
                intent.putExtra("supermarket",modelSupermarket);
                view.getContext().startActivity(intent);
            }
        });


        ///set data
        holder.supermarketNameTv.setText(name);
        holder.supermarketAddressTv.setText(supermarketAddress);

        holder.showRoute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                        Uri.parse("google.navigation:q=" +  supermarketList.get(position).getLatitude()+","+supermarketList.get(position).getLongitude()+ ""));
                view.getContext().startActivity(intent);
            }
        });

        /*
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onItemClicked(holder.getAdapterPosition(), supermarketList.get(holder.getAdapterPosition()));
            }
        });*/

        try{
            Picasso.get().load(icon).placeholder(R.drawable.ic_store).into(holder.supermarketIconIv);
        }
        catch (Exception e){
            holder.supermarketIconIv.setImageResource(R.drawable.ic_store);
        }

    }

    @Override
    public int getItemCount() {
        return supermarketList.size();
    }

    //view holder
    class HolderSupermarket extends RecyclerView.ViewHolder{

        public RatingBar ratingBar4;
        private ImageView supermarketIconIv,rateIv,shreviewIv;
        private TextView supermarketNameTv, supermarketAddressTv;
        private Button showRoute;

        public HolderSupermarket(@NonNull View itemView) {
            super(itemView);

            supermarketIconIv = itemView.findViewById(R.id.supermarketIconIv);
            supermarketNameTv = itemView.findViewById(R.id.supermarketNameTv);
            supermarketAddressTv = itemView.findViewById(R.id.supermarketAddressTv);
            showRoute = itemView.findViewById(R.id.showRoute);
            rateIv=itemView.findViewById(R.id.rateIv);
            shreviewIv=itemView.findViewById(R.id.shreviewIv);
        }
    }

    public interface SmResListener{
        void onItemClicked(int index, ModelSupermarket item);
    }
}
