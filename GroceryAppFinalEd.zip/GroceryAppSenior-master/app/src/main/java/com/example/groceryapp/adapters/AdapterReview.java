package com.example.groceryapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.groceryapp.R;
import com.example.groceryapp.models.ModelOrderUser;
import com.example.groceryapp.models.ModelReview;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AdapterReview extends RecyclerView.Adapter<AdapterReview.HolderReview> {
    private Context context;
    private List<ModelReview> reviewArrayList;

    public void submitList(List<ModelReview> list){
        reviewArrayList = list;
        notifyDataSetChanged();
    }

    public AdapterReview(Context context, ArrayList<ModelReview> reviewArrayList) {
        this.context = context;
        this.reviewArrayList = reviewArrayList;
    }

    @NonNull
    @Override
    public HolderReview onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.show_reviews,parent,false);

        return new HolderReview(view) ;
    }

    @Override
    public void onBindViewHolder(@NonNull HolderReview holder, int position) {
        ModelReview modelReview =reviewArrayList.get(position);
        String uid=modelReview.getUid();
        String ratings=modelReview.getRatings();
        String timestamp=modelReview.getTimestamp();
        String review=modelReview.getReview();

        loadUserDetails(modelReview,holder);

        DateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        if (timestamp != null){
            String formattedDate=df.format( new Date(Long.parseLong(timestamp)));
            holder.dateTV3.setText(formattedDate);
        }
        holder.ratingBar3.setRating(Float.parseFloat(ratings));
        holder.reviewTv3.setText(review);

    }

    private void loadUserDetails(ModelReview modelReview, HolderReview holder) {
        String uid=modelReview.getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(uid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String name=""+snapshot.child("name").getValue();
                        holder.nameTv3.setText(name);

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    @Override
    public int getItemCount() {
        return reviewArrayList.size();
    }

    class HolderReview extends RecyclerView.ViewHolder {
        private ImageView profileIv3;
        private TextView nameTv3,dateTV3,reviewTv3;
        private RatingBar ratingBar3;
        public HolderReview(View itemView)
        {
            super(itemView);

            profileIv3=itemView.findViewById(R.id.profileIv3);
            nameTv3=itemView.findViewById(R.id.nameTv3);
            ratingBar3=itemView.findViewById(R.id.ratingBar3);
            dateTV3=itemView.findViewById(R.id.dateTV3);
            reviewTv3=itemView.findViewById(R.id.reviewTv3);
        }

    }
}

