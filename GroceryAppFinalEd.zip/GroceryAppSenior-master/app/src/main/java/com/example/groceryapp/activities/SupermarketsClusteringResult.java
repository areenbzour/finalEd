package com.example.groceryapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.Toast;

import com.example.groceryapp.R;
import com.example.groceryapp.adapters.AdapterSmRes;
import com.example.groceryapp.adapters.AdapterSupermarket;
import com.example.groceryapp.models.ModelProduct;
import com.example.groceryapp.models.ModelSupermarket;
import com.google.android.gms.maps.GoogleMap;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SupermarketsClusteringResult extends AppCompatActivity implements AdapterSmRes.SmResListener {

    //private Adapter adapterSupermarket;
    private AdapterSmRes adapterSupermarket;

    List<ModelProduct> products1;
    List<ModelProduct> products2;
    List<ModelProduct> products3;

    //GoogleMap map;
   // Button btnShowRoute;
    Button showRouteBtn, closeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supermarkets_clustering_result);

        RecyclerView smResView = findViewById(R.id.smResView);
        showRouteBtn = findViewById(R.id.showRouteBtn);


        Intent intent = getIntent();
        Bundle args = intent.getBundleExtra("Bundle");
        ArrayList<ModelSupermarket> smRes = (ArrayList<ModelSupermarket>) args.getSerializable("Supermarkets");

        adapterSupermarket = new AdapterSmRes(SupermarketsClusteringResult.this, smRes, this);
        //set adapter
        smResView.setAdapter(adapterSupermarket);
        smResView.setLayoutManager(new LinearLayoutManager(this));

        if (args.getSerializable("Products1") != null){
            products1 = (List<ModelProduct>) args.getSerializable("Products1");
        }
        if (args.getSerializable("Products2") != null){
            products2 = (List<ModelProduct>) args.getSerializable("Products2");
        }
        if (args.getSerializable("Products3") != null){
            products3 = (List<ModelProduct>) args.getSerializable("Products3");
        }


        showRouteBtn = findViewById(R.id.showRouteBtn);
        closeBtn = findViewById(R.id.closeBtn);

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SupermarketsClusteringResult.this, MainUserActivity.class);
                startActivity(intent);
            }
        });


        Location ulocation = new Location("Ulocation");
            final DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users")
                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Location");

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Double ulatitude = snapshot.child("latitude").getValue(Double.class);
                    Double ulongitude = snapshot.child("longitude").getValue(Double.class);

                    ulocation.setLatitude(ulatitude);
                    ulocation.setLongitude(ulongitude);


                    // Drawing Route between user and results

                    showRouteBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //Intent i = new Intent(this)
                            //Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                            //Uri.parse("google.navigation:q=" +  31+","+31+ ""));
                            //Toast.makeText(SupermarketsClusteringResult.this, "User's Latitude: " + ulocation.getLatitude() +
                                    //"User's Longitude: " + ulocation.getLongitude(), Toast.LENGTH_SHORT).show();
                            String address = "https://www.google.com/maps/dir/" + String.valueOf(ulatitude) + ',' + String.valueOf(ulongitude);
                            if (smRes.size() == 1){
                                 address = "https://www.google.com/maps/dir/" + String.valueOf(ulatitude) + ',' + String.valueOf(ulongitude)
                                        +"/" + String.valueOf(smRes.get(0).getLatitude()) + ',' + String.valueOf(smRes.get(0).getLongitude());

                            }
                            if (smRes.size() == 2){
                                 address = "https://www.google.com/maps/dir/" + String.valueOf(ulatitude) + ',' + String.valueOf(ulongitude)
                                        +"/" + String.valueOf(smRes.get(0).getLatitude()) + ',' + String.valueOf(smRes.get(0).getLongitude())
                                        +"/" + String.valueOf(smRes.get(1).getLatitude()) + ',' + String.valueOf(smRes.get(1).getLongitude());

                            }
                            if (smRes.size() == 3) {
                                address = "https://www.google.com/maps/dir/" + String.valueOf(ulatitude) + ',' + String.valueOf(ulongitude)
                                        +"/" + String.valueOf(smRes.get(0).getLatitude()) + ',' + String.valueOf(smRes.get(0).getLongitude())
                                        +"/" + String.valueOf(smRes.get(1).getLatitude()) + ',' + String.valueOf(smRes.get(1).getLongitude())
                                        +"/" + String.valueOf(smRes.get(2).getLatitude()) + ',' + String.valueOf(smRes.get(2).getLongitude());
                            }
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(address));
                            startActivity(intent);
                        }
                    });

                    }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });





    }

    @Override
    public void onItemClicked(int index, ModelSupermarket item) {
        // open acctitiy,
        if (index == 0){
            Intent intent = new Intent(SupermarketsClusteringResult.this,ProductsOfCluster.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("Products", (Serializable) products1);
            intent.putExtra("Bundle", bundle);
            startActivity(intent);
        }
        if (index ==1){
            Intent intent = new Intent(SupermarketsClusteringResult.this,ProductsOfCluster.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("Products", (Serializable) products2);
            intent.putExtra("Bundle", bundle);
            startActivity(intent);
        }
        if (index ==2){
            Intent intent = new Intent(SupermarketsClusteringResult.this,ProductsOfCluster.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("Products", (Serializable) products3);
            intent.putExtra("Bundle", bundle);
            startActivity(intent);
        }
    }
}