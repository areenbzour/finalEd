package com.example.groceryapp.adapters;

import com.example.groceryapp.models.ModelProduct;

public interface AdapterCallback {
    void onProductRemoved(ModelProduct product);
}
